# GSE2: Gnome Sequencer Enhanced

## [2.6.55](https://github.com/TimothyLuke/GnomeSequencer-Enhanced/tree/2.6.55) (2021-06-09)
[Full Changelog](https://github.com/TimothyLuke/GnomeSequencer-Enhanced/compare/2.6.54...2.6.55) [Previous Releases](https://github.com/TimothyLuke/GnomeSequencer-Enhanced/releases)

- #846 Update ranks to internal API  
- #846 Dont print pcall passed  
- #846 Use GetSpellSubtext to obtain rank information.  
- #841  
    Build on Tag  
- #841 Update CI.yml  
- Migrate from Travis to Google Actions  